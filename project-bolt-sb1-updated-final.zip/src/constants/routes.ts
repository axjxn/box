export const ROUTES = {
  LOGIN: '/',
  ADMIN: {
    DASHBOARD: '/admin',
    BOXES: '/admin/boxes',
    STAFF: '/admin/staff',
    REPORTS: '/admin/reports',
  },
  AGENT: {
    DASHBOARD: '/agent',
    DELIVERIES: '/agent/deliveries',
    RETURNS: '/agent/returns',
  },
} as const;