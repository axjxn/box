import React from 'react';
import { Box, Package, Users, AlertTriangle } from 'lucide-react';
import type { Box as BoxType, Staff } from '../types';

interface DashboardProps {
  boxes: BoxType[];
  staff: Staff[];
}

export function Dashboard({ boxes, staff }: DashboardProps) {
  const totalBoxes = boxes.length;
  const deliveredBoxes = boxes.filter(box => box.status === 'delivered').length;
  const availableBoxes = boxes.filter(box => box.status === 'available').length;
  const overdueBoxes = boxes.filter(box => {
    if (box.status !== 'delivered') return false;
    const deliveryDate = new Date(box.deliveryDate!);
    const daysOut = Math.floor((Date.now() - deliveryDate.getTime()) / (1000 * 60 * 60 * 24));
    return daysOut > 7;
  }).length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4">
      <DashboardCard
        title="Total Boxes"
        value={totalBoxes}
        icon={<Box className="w-8 h-8 text-blue-500" />}
      />
      <DashboardCard
        title="Boxes Out"
        value={deliveredBoxes}
        icon={<Package className="w-8 h-8 text-green-500" />}
      />
      <DashboardCard
        title="Available Boxes"
        value={availableBoxes}
        icon={<Users className="w-8 h-8 text-purple-500" />}
      />
      <DashboardCard
        title="Overdue Returns"
        value={overdueBoxes}
        icon={<AlertTriangle className="w-8 h-8 text-red-500" />}
      />
    </div>
  );
}

interface DashboardCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
}

function DashboardCard({ title, value, icon }: DashboardCardProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-gray-500 text-sm">{title}</p>
          <p className="text-2xl font-bold mt-1">{value}</p>
        </div>
        {icon}
      </div>
    </div>
  );
}