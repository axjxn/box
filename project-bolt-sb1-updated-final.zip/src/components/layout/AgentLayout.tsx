import React from 'react';
import { Outlet } from 'react-router-dom';
import { Header } from './Header';
import { AgentSidebar } from './AgentSidebar';
import type { User } from '../../types';

interface AgentLayoutProps {
  user: User;
  onLogout: () => void;
}

export function AgentLayout({ user, onLogout }: AgentLayoutProps) {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header user={user} onLogout={onLogout} />
      <div className="flex">
        <AgentSidebar />
        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}