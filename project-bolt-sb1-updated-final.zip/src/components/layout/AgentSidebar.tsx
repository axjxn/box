import React from 'react';
import { NavLink } from 'react-router-dom';
import { Package, RotateCcw } from 'lucide-react';
import { ROUTES } from '../../constants/routes';

export function AgentSidebar() {
  return (
    <nav className="w-64 bg-white shadow-md min-h-[calc(100vh-64px)]">
      <div className="p-4">
        <ul className="space-y-2">
          <SidebarItem
            to={ROUTES.AGENT.DELIVERIES}
            icon={<Package className="w-5 h-5" />}
            label="New Delivery"
          />
          <SidebarItem
            to={ROUTES.AGENT.RETURNS}
            icon={<RotateCcw className="w-5 h-5" />}
            label="Process Return"
          />
        </ul>
      </div>
    </nav>
  );
}

interface SidebarItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
}

function SidebarItem({ to, icon, label }: SidebarItemProps) {
  return (
    <li>
      <NavLink
        to={to}
        className={({ isActive }) =>
          `flex items-center gap-3 px-4 py-2 rounded-md transition-colors ${
            isActive
              ? 'bg-blue-50 text-blue-600'
              : 'text-gray-600 hover:bg-gray-50'
          }`
        }
      >
        {icon}
        <span>{label}</span>
      </NavLink>
    </li>
  );
}