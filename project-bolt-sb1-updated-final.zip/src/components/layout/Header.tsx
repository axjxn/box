import React from 'react';
import { LogOut, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ROUTES } from '../../constants/routes';
import type { User as UserType } from '../../types';

interface HeaderProps {
  user: UserType;
  onLogout: () => void;
}

export function Header({ user, onLogout }: HeaderProps) {
  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link to={user.role === 'admin' ? ROUTES.ADMIN.DASHBOARD : ROUTES.AGENT.DASHBOARD}>
          <h1 className="text-xl font-bold text-blue-600">Fish Box Tracker</h1>
        </Link>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-gray-600" />
            <span className="text-sm font-medium">{user.name}</span>
          </div>
          <button
            onClick={onLogout}
            className="flex items-center gap-1 text-gray-600 hover:text-red-600"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
}