import React from 'react';
import { Package, ArrowRight, CheckCircle } from 'lucide-react';
import type { Box } from '../types';

interface BoxListProps {
  boxes: Box[];
  onUpdateStatus: (boxId: string, status: Box['status']) => void;
}

export function BoxList({ boxes, onUpdateStatus }: BoxListProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h2 className="text-xl font-semibold mb-4">Box Inventory</h2>
      <div className="space-y-4">
        {boxes.map((box) => (
          <div
            key={box.id}
            className="border rounded-lg p-4 flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <Package className="w-6 h-6 text-blue-500" />
              <div>
                <p className="font-medium">Box #{box.qrCode}</p>
                <p className="text-sm text-gray-500">
                  Status: {box.status.charAt(0).toUpperCase() + box.status.slice(1)}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              {box.status === 'available' && (
                <button
                  onClick={() => onUpdateStatus(box.id, 'delivered')}
                  className="flex items-center gap-1 bg-blue-500 text-white px-3 py-1 rounded-md hover:bg-blue-600"
                >
                  Deliver <ArrowRight className="w-4 h-4" />
                </button>
              )}
              {box.status === 'delivered' && (
                <button
                  onClick={() => onUpdateStatus(box.id, 'returned')}
                  className="flex items-center gap-1 bg-green-500 text-white px-3 py-1 rounded-md hover:bg-green-600"
                >
                  Return <CheckCircle className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}