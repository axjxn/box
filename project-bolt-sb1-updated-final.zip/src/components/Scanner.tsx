import React, { useState } from 'react';
import { ScanLine } from 'lucide-react';

interface ScannerProps {
  onScan: (qrCode: string) => void;
}

export function Scanner({ onScan }: ScannerProps) {
  const [qrInput, setQrInput] = useState('');

  // In a real app, this would use a proper QR scanner
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (qrInput.trim()) {
      onScan(qrInput);
      setQrInput('');
    }
  };

  return (
    <div className="p-4 bg-white rounded-lg shadow-md">
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div className="flex items-center gap-2">
          <ScanLine className="w-6 h-6 text-blue-500" />
          <h2 className="text-lg font-semibold">Box Scanner</h2>
        </div>
        <input
          type="text"
          value={qrInput}
          onChange={(e) => setQrInput(e.target.value)}
          placeholder="Scan QR Code or Enter Manually"
          className="p-2 border rounded-md"
        />
        <button
          type="submit"
          className="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600"
        >
          Process Scan
        </button>
      </form>
    </div>
  );
}