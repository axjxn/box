export interface Box {
  id: string;
  qrCode: string;
  status: 'available' | 'delivered' | 'returned';
  customerId?: string;
  staffId?: string;
  deliveryDate?: string;
  returnDate?: string;
}

export interface Customer {
  id: string;
  name: string;
  mobile: string;
  activeBoxes: string[];
}

export interface Staff {
  id: string;
  name: string;
  email: string;
  assignedBoxes: string[];
}

export interface User {
  id: string;
  email: string;
  role: 'admin' | 'staff';
  name: string;
}