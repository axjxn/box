import React, { useState } from 'react';
import { Scanner } from '../../components/Scanner';
import { CheckCircle } from 'lucide-react';

export function AgentReturnPage() {
  const [returnedBox, setReturnedBox] = useState<string | null>(null);

  const handleScan = async (qrCode: string) => {
    // In a real app, this would validate the box and process the return
    setReturnedBox(qrCode);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Process Return</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        {!returnedBox ? (
          <Scanner onScan={handleScan} />
        ) : (
          <div className="text-center py-8">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Return Processed!</h2>
            <p className="text-gray-600 mb-4">Box #{returnedBox} has been returned successfully.</p>
            <button
              onClick={() => setReturnedBox(null)}
              className="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600"
            >
              Process Another Return
            </button>
          </div>
        )}
      </div>
    </div>
  );
}