import React, { useState, useEffect } from 'react';
import { Scanner } from '../../components/Scanner';
import { Package, Plus, X } from 'lucide-react';
import { searchCustomers, addDelivery } from '../../utils/storage';

interface CustomerSuggestion {
  id: string;
  label: string;
  name: string;
  mobile: string;
}

export function AgentDeliveryPage() {
  const [selectedBoxes, setSelectedBoxes] = useState<string[]>([]);
  const [customerName, setCustomerName] = useState('');
  const [customerMobile, setCustomerMobile] = useState('');
  const [suggestions, setSuggestions] = useState<CustomerSuggestion[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (customerName || customerMobile) {
      const results = searchCustomers(customerName || customerMobile);
      setSuggestions(results);
    } else {
      setSuggestions([]);
    }
  }, [customerName, customerMobile]);

  const handleScan = (qrCode: string) => {
    if (!selectedBoxes.includes(qrCode)) {
      setSelectedBoxes(prev => [...prev, qrCode]);
    }
  };

  const removeBox = (boxId: string) => {
    setSelectedBoxes(prev => prev.filter(id => id !== boxId));
  };

  const selectCustomer = (suggestion: CustomerSuggestion) => {
    setCustomerName(suggestion.name);
    setCustomerMobile(suggestion.mobile);
    setShowSuggestions(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedBoxes.length > 0 && customerName && customerMobile) {
      addDelivery(customerName, customerMobile, selectedBoxes);
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        setSelectedBoxes([]);
        setCustomerName('');
        setCustomerMobile('');
      }, 2000);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">New Delivery</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <Scanner onScan={handleScan} />
        
        {selectedBoxes.length > 0 && (
          <div className="mt-4">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Selected Boxes:</h3>
            <div className="flex flex-wrap gap-2">
              {selectedBoxes.map(boxId => (
                <div key={boxId} className="flex items-center gap-1 bg-blue-50 text-blue-700 px-2 py-1 rounded">
                  <Package className="w-4 h-4" />
                  <span>{boxId}</span>
                  <button onClick={() => removeBox(boxId)} className="ml-1">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-lg font-semibold mb-4">Customer Details</h2>
        
        <div className="space-y-4">
          <div className="relative">
            <label className="block text-sm font-medium text-gray-700">Customer Name</label>
            <input
              type="text"
              value={customerName}
              onChange={e => {
                setCustomerName(e.target.value);
                setShowSuggestions(true);
              }}
              className="mt-1 block w-full p-2 border rounded-md"
              required
            />
            {showSuggestions && suggestions.length > 0 && (
              <div className="absolute z-10 w-full mt-1 bg-white border rounded-md shadow-lg">
                {suggestions.map(suggestion => (
                  <button
                    key={suggestion.id}
                    type="button"
                    onClick={() => selectCustomer(suggestion)}
                    className="w-full text-left px-4 py-2 hover:bg-gray-50"
                  >
                    {suggestion.label}
                  </button>
                ))}
              </div>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700">Mobile Number</label>
            <input
              type="tel"
              value={customerMobile}
              onChange={e => setCustomerMobile(e.target.value)}
              className="mt-1 block w-full p-2 border rounded-md"
              required
            />
          </div>

          <button
            type="submit"
            disabled={selectedBoxes.length === 0 || !customerName || !customerMobile}
            className="w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 disabled:bg-gray-300"
          >
            Complete Delivery
          </button>
        </div>
      </form>

      {success && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-6 rounded-lg shadow-xl">
            <h3 className="text-xl font-semibold text-green-600 mb-2">Delivery Completed!</h3>
            <p>Boxes have been assigned to {customerName}</p>
          </div>
        </div>
      )}
    </div>
  );
}