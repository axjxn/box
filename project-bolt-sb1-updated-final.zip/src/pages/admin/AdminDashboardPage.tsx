import React from 'react';
import { Dashboard } from '../../components/Dashboard';
import { BoxList } from '../../components/BoxList';
import { getBoxes } from '../../utils/storage';

export function AdminDashboardPage() {
  const boxes = getBoxes();
  const mockStaff = [{ id: '1', name: 'John Doe', email: 'john@example.com', assignedBoxes: [] }];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
      <Dashboard boxes={boxes} staff={mockStaff} />
      <div className="mt-8">
        <BoxList boxes={boxes} onUpdateStatus={() => {}} />
      </div>
    </div>
  );
}