import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { LoginPage } from './pages/auth/LoginPage';
import { AdminLayout } from './components/layout/AdminLayout';
import { AgentLayout } from './components/layout/AgentLayout';
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AgentDeliveryPage } from './pages/agent/AgentDeliveryPage';
import { AgentReturnPage } from './pages/agent/AgentReturnPage';
import { ROUTES } from './constants/routes';

function App() {
  const handleLogout = () => {
    // In a real app, this would handle logout logic
    window.location.href = ROUTES.LOGIN;
  };

  return (
    <BrowserRouter>
      <Routes>
        <Route path={ROUTES.LOGIN} element={<LoginPage />} />
        
        {/* Admin Routes */}
        <Route
          path={ROUTES.ADMIN.DASHBOARD}
          element={<AdminLayout user={{ id: '1', email: 'admin@example.com', name: 'Admin', role: 'admin' }} onLogout={handleLogout} />}
        >
          <Route index element={<AdminDashboardPage />} />
        </Route>

        {/* Agent Routes */}
        <Route
          path={ROUTES.AGENT.DASHBOARD}
          element={<AgentLayout user={{ id: '2', email: 'agent@example.com', name: 'Agent', role: 'staff' }} onLogout={handleLogout} />}
        >
          <Route index element={<Navigate to={ROUTES.AGENT.DELIVERIES} replace />} />
          <Route path={ROUTES.AGENT.DELIVERIES} element={<AgentDeliveryPage />} />
          <Route path={ROUTES.AGENT.RETURNS} element={<AgentReturnPage />} />
        </Route>

        <Route path="*" element={<Navigate to={ROUTES.LOGIN} replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;