export const formatDate = (date: string) => {
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
};

export const isOverdue = (deliveryDate: string, daysThreshold = 7) => {
  const date = new Date(deliveryDate);
  const daysOut = Math.floor((Date.now() - date.getTime()) / (1000 * 60 * 60 * 24));
  return daysOut > daysThreshold;
};