import { User } from '../types';

// In a real app, these would be stored securely in a database
const MOCK_USERS = [
  {
    id: '1',
    email: 'admin@example.com',
    password: 'admin123',
    name: 'Admin User',
    role: 'admin' as const,
  },
  {
    id: '2',
    email: 'agent@example.com',
    password: 'agent123',
    name: 'Delivery Agent',
    role: 'staff' as const,
  },
];

export const authenticateUser = (email: string, password: string): User | null => {
  const user = MOCK_USERS.find(
    (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
  );

  if (!user) return null;

  // Don't include password in the returned user object
  const { password: _, ...userWithoutPassword } = user;
  return userWithoutPassword;
};

export const isAdmin = (user: User) => user.role === 'admin';
export const isAgent = (user: User) => user.role === 'staff';