// Mock database storage
let customers: Record<string, { name: string; mobile: string; boxes: string[] }> = {};
let boxes: Record<string, { qrCode: string; status: 'available' | 'delivered' | 'returned'; customerId?: string }> = {
  'BOX001': { qrCode: 'BOX001', status: 'available' },
  'BOX002': { qrCode: 'BOX002', status: 'available' },
  'BOX003': { qrCode: 'BOX003', status: 'available' },
};

export const getCustomers = () => Object.entries(customers).map(([id, data]) => ({
  id,
  ...data,
}));

export const searchCustomers = (query: string) => {
  const lowercaseQuery = query.toLowerCase();
  return Object.entries(customers)
    .filter(([_, data]) => 
      data.name.toLowerCase().includes(lowercaseQuery) ||
      data.mobile.includes(query)
    )
    .map(([id, data]) => ({
      id,
      label: `${data.name} (${data.mobile})`,
      ...data,
    }));
};

export const addDelivery = (customerName: string, customerMobile: string, boxIds: string[]) => {
  const customerId = `${customerName}-${customerMobile}`.replace(/\s+/g, '-').toLowerCase();
  
  if (!customers[customerId]) {
    customers[customerId] = {
      name: customerName,
      mobile: customerMobile,
      boxes: [],
    };
  }
  
  boxIds.forEach(boxId => {
    if (boxes[boxId]) {
      boxes[boxId].status = 'delivered';
      boxes[boxId].customerId = customerId;
      customers[customerId].boxes.push(boxId);
    }
  });
  
  return { customerId, customer: customers[customerId] };
};

export const processReturn = (boxId: string) => {
  const box = boxes[boxId];
  if (box && box.customerId) {
    box.status = 'returned';
    const customer = customers[box.customerId];
    if (customer) {
      customer.boxes = customer.boxes.filter(id => id !== boxId);
    }
    delete box.customerId;
    return true;
  }
  return false;
};

export const getBoxes = () => Object.entries(boxes).map(([id, data]) => ({
  id,
  ...data,
}));